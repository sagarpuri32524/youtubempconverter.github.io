# youtube-to-mp3-converter-php-script

Support: api@youtube6download.top

<h3>How to install this script?</h3>
First, Download it from here.
Then, upload the zip file on the webserver/localhost and unzip it.
Just browse the web directory or webpage where you've upload it.
That's it! Ready for use!

You are allowed to make any change what ever you want!

<h4>Features</h4>
<ul>
<li>No Conding skills needed.</li>
<li>No use of database</li>
<li>Works perfect on shared server which means no vps/dedicated server needed.</li>
<li>No need to install any plugin on your sever side like youtube-dl or ffmpeg.</li>
<li>Comes with Ad space, so just paste your ad code.</li>
<li>Fully optimized for mobile, desktop or tablet powered by bootstraps.</li>
<li>Most important thing is its free and always will be!</li>
</ul>
